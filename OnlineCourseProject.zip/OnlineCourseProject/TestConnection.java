import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestConnection {
    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@LAPTOP-PC6KPOAP:1522/XE";
        String username = "system";
        String password = "2005";

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection(url, username, password);
            System.out.println("Database connected successfully!");

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT table_name FROM user_tables WHERE table_name IN ('USERS', 'COURSES', 'ENROLLMENTS')");

            System.out.println("\nExisting tables:");
            boolean hasUsers = false, hasCourses = false, hasEnrollments = false;
            while (rs.next()) {
                String tableName = rs.getString("table_name");
                System.out.println("- " + tableName);
                if (tableName.equals("USERS")) hasUsers = true;
                if (tableName.equals("COURSES")) hasCourses = true;
                if (tableName.equals("ENROLLMENTS")) hasEnrollments = true;
            }

            if (hasUsers && hasCourses && hasEnrollments) {
                System.out.println("\nAll required tables exist!");
            } else {
                System.out.println("\nMissing tables! Please execute schema.sql");
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            System.out.println("Database connection failed!");
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
