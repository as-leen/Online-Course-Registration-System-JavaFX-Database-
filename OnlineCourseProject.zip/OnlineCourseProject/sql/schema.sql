-- Online Course Registration System - Database Schema
-- Oracle Database

-- Drop tables if they exist (for clean recreation)
DROP TABLE Enrollments CASCADE CONSTRAINTS;
DROP TABLE Courses CASCADE CONSTRAINTS;
DROP TABLE Users CASCADE CONSTRAINTS;

-- Drop sequences if they exist
DROP SEQUENCE user_seq;
DROP SEQUENCE course_seq;
DROP SEQUENCE enrollment_seq;

-- Create sequences for auto-increment IDs
CREATE SEQUENCE user_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE course_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE enrollment_seq START WITH 1 INCREMENT BY 1;

-- Users Table
CREATE TABLE Users (
    user_id NUMBER PRIMARY KEY,
    username VARCHAR2(50) NOT NULL UNIQUE,
    password VARCHAR2(50) NOT NULL,
    first_name VARCHAR2(50),
    last_name VARCHAR2(50),
    role VARCHAR2(20) NOT NULL CHECK (role IN ('STUDENT', 'PROFESSOR', 'ADMIN'))
);

-- Courses Table
CREATE TABLE Courses (
    course_id NUMBER PRIMARY KEY,
    course_code VARCHAR2(20) NOT NULL,
    course_name VARCHAR2(100) NOT NULL,
    credits NUMBER NOT NULL CHECK (credits > 0),
    professor_id NUMBER,
    is_available NUMBER(1) DEFAULT 1 CHECK (is_available IN (0, 1)),
    CONSTRAINT fk_professor FOREIGN KEY (professor_id) REFERENCES Users(user_id) ON DELETE SET NULL
);

-- Enrollments Table
CREATE TABLE Enrollments (
    enrollment_id NUMBER PRIMARY KEY,
    student_id NUMBER NOT NULL,
    course_id NUMBER NOT NULL,
    enrollment_date DATE DEFAULT SYSDATE,
    CONSTRAINT fk_student FOREIGN KEY (student_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_course FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE,
    CONSTRAINT unique_enrollment UNIQUE (student_id, course_id)
);

COMMIT;
