-- Online Course Registration System - Sample Data
-- Oracle Database

-- Insert Administrator (user_id: 1)
INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'admin', 'admin123', 'System', 'Administrator', 'ADMIN');

-- Insert Professors (user_id: 2-4)
INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'prof1', 'pass123', 'John', 'Smith', 'PROFESSOR');

INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'prof2', 'pass123', 'Sarah', 'Johnson', 'PROFESSOR');

INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'prof3', 'pass123', 'Michael', 'Williams', 'PROFESSOR');

-- Insert Students (user_id: 5-9)
INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'student1', 'pass123', 'Ahmed', 'Ali', 'STUDENT');

INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'student2', 'pass123', 'Fatima', 'Hassan', 'STUDENT');

INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'student3', 'pass123', 'Omar', 'Abdullah', 'STUDENT');

INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'student4', 'pass123', 'Maha', 'Mohammed', 'STUDENT');

INSERT INTO Users (user_id, username, password, first_name, last_name, role)
VALUES (user_seq.NEXTVAL, 'student5', 'pass123', 'Khalid', 'Ibrahim', 'STUDENT');

-- Insert Courses (course_id: 1-10)
INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'CS101', 'Introduction to Programming', 3, 2, 1);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'CS201', 'Data Structures', 3, 2, 1);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'CS313', 'Advanced Programming', 3, 3, 1);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'CS340', 'Database Systems', 4, 3, 1);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'MATH101', 'Calculus I', 4, 4, 1);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'MATH201', 'Calculus II', 4, 4, 1);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'CS450', 'Software Engineering', 3, 2, 1);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'CS460', 'Computer Networks', 3, 3, 1);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'CS470', 'Operating Systems', 3, 2, 0);

INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available)
VALUES (course_seq.NEXTVAL, 'CS480', 'Artificial Intelligence', 4, 4, 1);

-- Insert Sample Enrollments
INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 5, 1, SYSDATE);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 5, 5, SYSDATE);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 6, 1, SYSDATE);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 6, 3, SYSDATE);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 7, 2, SYSDATE);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 7, 4, SYSDATE);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 8, 3, SYSDATE);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 9, 1, SYSDATE);

COMMIT;
