import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class ExecuteSQL {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: java ExecuteSQL <sql-file>");
            return;
        }

        String url = "jdbc:oracle:thin:@LAPTOP-PC6KPOAP:1522/XE";
        String username = "system";
        String password = "2005";

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection conn = DriverManager.getConnection(url, username, password);
            Statement stmt = conn.createStatement();

            BufferedReader reader = new BufferedReader(new FileReader(args[0]));
            StringBuilder sql = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("--")) {
                    continue;
                }
                sql.append(line).append(" ");
                if (line.endsWith(";")) {
                    String query = sql.toString().replace(";", "").trim();
                    if (!query.isEmpty()) {
                        try {
                            stmt.execute(query);
                            System.out.println("Executed: " + query.substring(0, Math.min(50, query.length())) + "...");
                        } catch (Exception e) {
                            System.out.println("Warning: " + e.getMessage());
                        }
                    }
                    sql = new StringBuilder();
                }
            }

            reader.close();
            conn.commit();
            stmt.close();
            conn.close();

            System.out.println("\nSQL file executed successfully!");

        } catch (Exception e) {
            System.out.println("Error executing SQL file!");
            e.printStackTrace();
        }
    }
}
