package util;

import dao.DatabaseConnection;
import dao.DatabaseException;
import java.sql.*;

public class CheckProfessors {

    public static void main(String[] args) {
        System.out.println("=== Checking Professors ===");

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM Users WHERE role = 'PROFESSOR'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            int count = 0;
            while (rs.next()) {
                count++;
                System.out.println("\nProfessor " + count + ":");
                System.out.println("  user_id: " + rs.getInt("user_id"));
                System.out.println("  username: " + rs.getString("username"));
                System.out.println("  first_name: " + rs.getString("first_name"));
                System.out.println("  last_name: " + rs.getString("last_name"));
            }

            System.out.println("\nTotal professors: " + count);

            // Now check which professors are referenced in courses
            System.out.println("\n=== Professors referenced in Courses ===");
            sql = "SELECT DISTINCT professor_id FROM Courses WHERE professor_id IS NOT NULL ORDER BY professor_id";
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                int profId = rs.getInt("professor_id");
                System.out.println("  Professor ID: " + profId);
            }

            rs.close();
            stmt.close();

        } catch (DatabaseException e) {
            System.err.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("SQL Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
