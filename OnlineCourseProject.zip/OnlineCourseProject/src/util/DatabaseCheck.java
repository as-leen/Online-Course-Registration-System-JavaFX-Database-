package util;

import dao.DatabaseConnection;
import dao.DatabaseException;
import java.sql.*;

public class DatabaseCheck {

    public static void main(String[] args) {
        System.out.println("=== Database Connection Check ===");

        try {
            Connection conn = DatabaseConnection.getConnection();
            System.out.println("✓ Database connection successful!");

            // Check if Courses table exists
            System.out.println("\n=== Checking Courses Table ===");
            String sql = "SELECT * FROM Courses";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            // Get column info
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            System.out.println("Columns in Courses table:");
            for (int i = 1; i <= columnCount; i++) {
                System.out.println("  - " + metaData.getColumnName(i) + " (" + metaData.getColumnTypeName(i) + ")");
            }

            // Count rows
            int count = 0;
            while (rs.next()) {
                count++;
                System.out.println("\nRow " + count + ":");
                System.out.println("  course_id: " + rs.getInt("course_id"));
                System.out.println("  course_code: " + rs.getString("course_code"));
                System.out.println("  course_name: " + rs.getString("course_name"));
                System.out.println("  credits: " + rs.getInt("credits"));
                System.out.println("  professor_id: " + rs.getInt("professor_id") + " (wasNull: " + rs.wasNull() + ")");
                System.out.println("  is_available: " + rs.getInt("is_available"));
            }

            System.out.println("\nTotal courses: " + count);

            rs.close();
            stmt.close();

        } catch (DatabaseException e) {
            System.err.println("✗ Database connection failed: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("✗ SQL Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
