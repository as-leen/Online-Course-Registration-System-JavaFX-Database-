package dao;


import model.Course;
import model.Professor;
import java.sql.*;
import java.util.ArrayList;

public class CourseDAO implements Manageable<Course> {

    private UserDAO userDAO = new UserDAO();

    public ArrayList<Course> getAllCourses() throws DatabaseException {
        ArrayList<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM Courses ORDER BY course_code";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                courses.add(createCourseFromResultSet(rs));
            }
            return courses;
        } catch (SQLException e) {
            System.err.println("SQL Error in getAllCourses: " + e.getMessage());
            e.printStackTrace();
            throw new DatabaseException("Failed to retrieve courses: " + e.getMessage(), e);
        } catch (Exception e) {
            System.err.println("Error in getAllCourses: " + e.getMessage());
            e.printStackTrace();
            throw new DatabaseException("Failed to retrieve courses: " + e.getMessage());
        }
    }

    public ArrayList<Course> getAvailableCourses() throws DatabaseException {
        ArrayList<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM Courses WHERE is_available = 1 ORDER BY course_code";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                courses.add(createCourseFromResultSet(rs));
            }
            return courses;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve available courses", e);
        }
    }

    public ArrayList<Course> getCoursesByProfessor(int professorId) throws DatabaseException {
        ArrayList<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM Courses WHERE professor_id = ? ORDER BY course_code";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, professorId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                courses.add(createCourseFromResultSet(rs));
            }
            return courses;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve professor courses", e);
        }
    }

    public Course getCourseById(int courseId) throws DatabaseException {
        String sql = "SELECT * FROM Courses WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return createCourseFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve course", e);
        }
    }

    @Override
    public void add(Course course) throws DatabaseException {
        String sql = "INSERT INTO Courses (course_id, course_code, course_name, credits, professor_id, is_available) " +
                     "VALUES (course_seq.NEXTVAL, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, course.getCourseCode());
            stmt.setString(2, course.getCourseName());
            stmt.setInt(3, course.getCredits());

            // Set professor_id as NULL if no professor assigned
            if (course.getProfessor() != null) {
                stmt.setInt(4, course.getProfessor().getUserId());
            } else {
                stmt.setNull(4, java.sql.Types.INTEGER);
            }

            stmt.setInt(5, course.isAvailable() ? 1 : 0);

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add course: " + e.getMessage(), e);
        }
    }

    @Override
    public void update(Course course) throws DatabaseException {
        String sql = "UPDATE Courses SET course_code = ?, course_name = ?, credits = ?, professor_id = ?, is_available = ? " +
                     "WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, course.getCourseCode());
            stmt.setString(2, course.getCourseName());
            stmt.setInt(3, course.getCredits());

            // Set professor_id as NULL if no professor assigned
            if (course.getProfessor() != null) {
                stmt.setInt(4, course.getProfessor().getUserId());
            } else {
                stmt.setNull(4, java.sql.Types.INTEGER);
            }

            stmt.setInt(5, course.isAvailable() ? 1 : 0);
            stmt.setInt(6, course.getCourseId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update course: " + e.getMessage(), e);
        }
    }

    public void updateAvailability(int courseId, boolean isAvailable) throws DatabaseException {
        String sql = "UPDATE Courses SET is_available = ? WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, isAvailable ? 1 : 0);
            stmt.setInt(2, courseId);

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update course availability", e);
        }
    }

    @Override
    public void delete(int courseId) throws DatabaseException {
        String sql = "DELETE FROM Courses WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, courseId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete course", e);
        }
    }

    private Course createCourseFromResultSet(ResultSet rs) throws SQLException, DatabaseException {
        Course course = new Course();
        course.setCourseId(rs.getInt("course_id"));
        course.setCourseCode(rs.getString("course_code"));
        course.setCourseName(rs.getString("course_name"));
        course.setCredits(rs.getInt("credits"));
        course.setAvailable(rs.getInt("is_available") == 1);

        // Handle professor assignment - check for NULL and valid professor
        int professorId = rs.getInt("professor_id");
        if (!rs.wasNull() && professorId > 0) {
            try {
                Professor prof = (Professor) userDAO.getUserById(professorId);
                if (prof != null) {
                    course.setProfessor(prof);
                }
            } catch (Exception e) {
                // Professor not found or error - leave professor as null
                System.err.println("Warning: Could not load professor " + professorId + " for course " + course.getCourseCode());
            }
        }

        return course;
    }
}
