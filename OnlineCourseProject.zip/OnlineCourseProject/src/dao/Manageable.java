package dao;



public interface Manageable<T> {
    void add(T entity) throws DatabaseException;
    void update(T entity) throws DatabaseException;
    void delete(int id) throws DatabaseException;
}
