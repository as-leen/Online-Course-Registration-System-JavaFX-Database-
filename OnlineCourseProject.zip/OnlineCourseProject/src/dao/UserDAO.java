package dao;

import model.AuthenticationException;
import model.*;
import java.sql.*;
import java.util.ArrayList;

public class UserDAO implements Manageable<User> {

    public User login(String username, String password, String role) throws AuthenticationException, DatabaseException {
        String sql = "SELECT * FROM Users WHERE username = ? AND password = ? AND role = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, role);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return createUserFromResultSet(rs);
            } else {
                throw new AuthenticationException("Invalid username, password, or role");
            }
        } catch (SQLException e) {
            throw new DatabaseException("Login failed", e);
        }
    }

    public ArrayList<User> getAllUsers() throws DatabaseException {
        ArrayList<User> users = new ArrayList<>();
        String sql = "SELECT * FROM Users ORDER BY user_id";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                users.add(createUserFromResultSet(rs));
            }
            return users;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve users", e);
        }
    }

    public User getUserById(int userId) throws DatabaseException {
        String sql = "SELECT * FROM Users WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return createUserFromResultSet(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve user", e);
        }
    }

    public ArrayList<Professor> getAllProfessors() throws DatabaseException {
        ArrayList<Professor> professors = new ArrayList<>();
        String sql = "SELECT * FROM Users WHERE role = 'PROFESSOR' ORDER BY last_name";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Professor prof = new Professor();
                prof.setUserId(rs.getInt("user_id"));
                prof.setUsername(rs.getString("username"));
                prof.setPassword(rs.getString("password"));
                prof.setFirstName(rs.getString("first_name"));
                prof.setLastName(rs.getString("last_name"));
                prof.setRole(rs.getString("role"));
                professors.add(prof);
            }
            return professors;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve professors", e);
        }
    }

    @Override
    public void add(User user) throws DatabaseException {
        String sql = "INSERT INTO Users (user_id, username, password, first_name, last_name, role) " +
                     "VALUES (user_seq.NEXTVAL, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getFirstName());
            stmt.setString(4, user.getLastName());
            stmt.setString(5, user.getRole());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add user", e);
        }
    }

    @Override
    public void update(User user) throws DatabaseException {
        String sql = "UPDATE Users SET username = ?, password = ?, first_name = ?, last_name = ?, role = ? " +
                     "WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getFirstName());
            stmt.setString(4, user.getLastName());
            stmt.setString(5, user.getRole());
            stmt.setInt(6, user.getUserId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update user", e);
        }
    }

    @Override
    public void delete(int userId) throws DatabaseException {
        String sql = "DELETE FROM Users WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete user", e);
        }
    }

    private User createUserFromResultSet(ResultSet rs) throws SQLException {
        String role = rs.getString("role");
        User user;

        switch (role) {
            case "STUDENT":
                user = new Student();
                break;
            case "PROFESSOR":
                user = new Professor();
                break;
            case "ADMIN":
                user = new Administrator();
                break;
            default:
                throw new SQLException("Unknown user role: " + role);
        }

        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setFirstName(rs.getString("first_name"));
        user.setLastName(rs.getString("last_name"));
        user.setRole(role);

        return user;
    }
}
