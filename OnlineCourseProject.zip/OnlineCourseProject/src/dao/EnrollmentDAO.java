package dao;


import model.*;
import java.sql.*;
import java.util.ArrayList;

public class EnrollmentDAO implements Manageable<Enrollment> {

    private UserDAO userDAO = new UserDAO();
    private CourseDAO courseDAO = new CourseDAO();

    public void enrollStudent(int studentId, int courseId) throws DatabaseException {
        String sql = "INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date) " +
                     "VALUES (enrollment_seq.NEXTVAL, ?, ?, SYSDATE)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);

            stmt.executeUpdate();
        } catch (SQLException e) {
            if (e.getErrorCode() == 1) {
                throw new DatabaseException("Student is already enrolled in this course");
            }
            throw new DatabaseException("Failed to enroll student", e);
        }
    }

    public void dropCourse(int studentId, int courseId) throws DatabaseException {
        String sql = "DELETE FROM Enrollments WHERE student_id = ? AND course_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new DatabaseException("Enrollment not found");
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to drop course", e);
        }
    }

    public ArrayList<Course> getEnrollmentsByStudent(int studentId) throws DatabaseException {
        ArrayList<Course> courses = new ArrayList<>();
        String sql = "SELECT c.* FROM Courses c " +
                     "JOIN Enrollments e ON c.course_id = e.course_id " +
                     "WHERE e.student_id = ? " +
                     "ORDER BY c.course_code";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Course course = new Course();
                course.setCourseId(rs.getInt("course_id"));
                course.setCourseCode(rs.getString("course_code"));
                course.setCourseName(rs.getString("course_name"));
                course.setCredits(rs.getInt("credits"));
                course.setAvailable(rs.getInt("is_available") == 1);

                int professorId = rs.getInt("professor_id");
                if (professorId > 0) {
                    Professor prof = (Professor) userDAO.getUserById(professorId);
                    course.setProfessor(prof);
                }

                courses.add(course);
            }
            return courses;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve student enrollments", e);
        }
    }

    public ArrayList<Student> getEnrollmentsByCourse(int courseId) throws DatabaseException {
        ArrayList<Student> students = new ArrayList<>();
        String sql = "SELECT u.* FROM Users u " +
                     "JOIN Enrollments e ON u.user_id = e.student_id " +
                     "WHERE e.course_id = ? AND u.role = 'STUDENT' " +
                     "ORDER BY u.last_name, u.first_name";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Student student = new Student();
                student.setUserId(rs.getInt("user_id"));
                student.setUsername(rs.getString("username"));
                student.setPassword(rs.getString("password"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setRole(rs.getString("role"));
                students.add(student);
            }
            return students;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve course enrollments", e);
        }
    }

    @Override
    public void add(Enrollment enrollment) throws DatabaseException {
        enrollStudent(enrollment.getStudent().getUserId(), enrollment.getCourse().getCourseId());
    }

    @Override
    public void update(Enrollment enrollment) throws DatabaseException {
        throw new UnsupportedOperationException("Updating enrollments is not supported");
    }

    @Override
    public void delete(int enrollmentId) throws DatabaseException {
        String sql = "DELETE FROM Enrollments WHERE enrollment_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, enrollmentId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete enrollment", e);
        }
    }
}
