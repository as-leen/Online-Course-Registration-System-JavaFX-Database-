package controller;

import dao.CourseDAO;
import dao.EnrollmentDAO;
import dao.DatabaseException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Course;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Consolidated controller for student course views
 * Handles both viewing available courses and student schedule
 */
public class StudentCourseViewController implements Initializable {

    @FXML
    private TabPane courseViewTabPane;

    // Available Courses Tab Components
    @FXML
    private TableView<Course> availableCoursesTable;

    @FXML
    private TableColumn<Course, String> availCourseCodeColumn;

    @FXML
    private TableColumn<Course, String> availCourseNameColumn;

    @FXML
    private TableColumn<Course, Integer> availCreditsColumn;

    @FXML
    private TableColumn<Course, String> availProfessorColumn;

    @FXML
    private TableColumn<Course, String> availabilityColumn;

    // My Schedule Tab Components
    @FXML
    private TableView<Course> scheduleTable;

    @FXML
    private TableColumn<Course, String> schedCourseCodeColumn;

    @FXML
    private TableColumn<Course, String> schedCourseNameColumn;

    @FXML
    private TableColumn<Course, Integer> schedCreditsColumn;

    @FXML
    private TableColumn<Course, String> schedProfessorColumn;

    private CourseDAO courseDAO = new CourseDAO();
    private EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private User currentUser;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        currentUser = LoginController.getCurrentUser();

        // Initialize Available Courses Tab
        availCourseCodeColumn.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        availCourseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        availCreditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        availProfessorColumn.setCellValueFactory(new PropertyValueFactory<>("professorName"));
        availabilityColumn.setCellValueFactory(new PropertyValueFactory<>("availabilityStatus"));

        // Initialize My Schedule Tab
        schedCourseCodeColumn.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        schedCourseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        schedCreditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        schedProfessorColumn.setCellValueFactory(new PropertyValueFactory<>("professorName"));

        // Load data
        loadAvailableCourses();
        loadSchedule();

        // Add tab change listener to refresh data
        courseViewTabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab != null) {
                loadAvailableCourses();
                loadSchedule();
            }
        });
    }

    private void loadAvailableCourses() {
        try {
            ArrayList<Course> courses = courseDAO.getAvailableCourses();
            ObservableList<Course> courseList = FXCollections.observableArrayList(courses);
            availableCoursesTable.setItems(courseList);
        } catch (DatabaseException e) {
            showError("Failed to load courses: " + e.getMessage());
        }
    }

    private void loadSchedule() {
        try {
            ArrayList<Course> courses = enrollmentDAO.getEnrollmentsByStudent(currentUser.getUserId());
            ObservableList<Course> courseList = FXCollections.observableArrayList(courses);
            scheduleTable.setItems(courseList);
        } catch (DatabaseException e) {
            showError("Failed to load schedule: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack() {
        loadScene("/fxml/StudentDashboard.fxml", "Student Dashboard");
    }

    private void loadScene(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) courseViewTabPane.getScene().getWindow();
            stage.setScene(new Scene(root, 800, 600));
            stage.setTitle(title);
        } catch (IOException e) {
            showError("Failed to load scene: " + e.getMessage());
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
