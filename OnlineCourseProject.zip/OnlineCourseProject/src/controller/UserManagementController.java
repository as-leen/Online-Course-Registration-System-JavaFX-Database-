package controller;

import dao.UserDAO;
import dao.DatabaseException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class UserManagementController implements Initializable {

    @FXML
    private TextField usernameField;

    @FXML
    private TextField passwordField;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private ComboBox<String> roleComboBox;

    @FXML
    private TableView<User> usersTable;

    @FXML
    private TableColumn<User, Integer> userIdColumn;

    @FXML
    private TableColumn<User, String> usernameColumn;

    @FXML
    private TableColumn<User, String> firstNameColumn;

    @FXML
    private TableColumn<User, String> lastNameColumn;

    @FXML
    private TableColumn<User, String> roleColumn;

    private UserDAO userDAO = new UserDAO();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        roleComboBox.setItems(FXCollections.observableArrayList("STUDENT", "PROFESSOR", "ADMIN"));

        userIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));

        usersTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                populateFields(newSelection);
            }
        });

        loadUsers();
    }

    private void loadUsers() {
        try {
            ArrayList<User> users = userDAO.getAllUsers();
            ObservableList<User> userList = FXCollections.observableArrayList(users);
            usersTable.setItems(userList);
        } catch (DatabaseException e) {
            showError("Failed to load users: " + e.getMessage());
        }
    }

    private void populateFields(User user) {
        usernameField.setText(user.getUsername());
        passwordField.setText(user.getPassword());
        firstNameField.setText(user.getFirstName());
        lastNameField.setText(user.getLastName());
        roleComboBox.setValue(user.getRole());
    }

    @FXML
    private void handleAdd() {
        if (!validateInput()) {
            return;
        }

        try {
            User user = createUserFromFields();
            userDAO.add(user);
            showSuccess("User added successfully");
            loadUsers();
            handleClear();
        } catch (DatabaseException e) {
            showError("Failed to add user: " + e.getMessage());
        }
    }

    @FXML
    private void handleUpdate() {
        User selectedUser = usersTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showWarning("Please select a user to update");
            return;
        }

        if (!validateInput()) {
            return;
        }

        try {
            User user = createUserFromFields();
            user.setUserId(selectedUser.getUserId());
            userDAO.update(user);
            showSuccess("User updated successfully");
            loadUsers();
            handleClear();
        } catch (DatabaseException e) {
            showError("Failed to update user: " + e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        User selectedUser = usersTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showWarning("Please select a user to delete");
            return;
        }

        try {
            userDAO.delete(selectedUser.getUserId());
            showSuccess("User deleted successfully");
            loadUsers();
            handleClear();
        } catch (DatabaseException e) {
            showError("Failed to delete user: " + e.getMessage());
        }
    }

    @FXML
    private void handleClear() {
        usernameField.clear();
        passwordField.clear();
        firstNameField.clear();
        lastNameField.clear();
        roleComboBox.setValue(null);
        usersTable.getSelectionModel().clearSelection();
    }

    @FXML
    private void handleBack() {
        loadScene("/fxml/AdminDashboard.fxml", "Admin Dashboard");
    }

    private boolean validateInput() {
        if (usernameField.getText().trim().isEmpty() ||
            passwordField.getText().trim().isEmpty() ||
            firstNameField.getText().trim().isEmpty() ||
            lastNameField.getText().trim().isEmpty() ||
            roleComboBox.getValue() == null) {
            showWarning("Please fill in all fields");
            return false;
        }
        return true;
    }

    private User createUserFromFields() {
        String role = roleComboBox.getValue();
        User user;

        switch (role) {
            case "STUDENT":
                user = new Student();
                break;
            case "PROFESSOR":
                user = new Professor();
                break;
            case "ADMIN":
                user = new Administrator();
                break;
            default:
                user = new Student();
        }

        user.setUsername(usernameField.getText().trim());
        user.setPassword(passwordField.getText().trim());
        user.setFirstName(firstNameField.getText().trim());
        user.setLastName(lastNameField.getText().trim());
        user.setRole(role);

        return user;
    }

    private void loadScene(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) usersTable.getScene().getWindow();
            stage.setScene(new Scene(root, 800, 600));
            stage.setTitle(title);
        } catch (IOException e) {
            System.err.println("Failed to load scene: " + e.getMessage());
        }
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
