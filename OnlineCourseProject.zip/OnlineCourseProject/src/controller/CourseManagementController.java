package controller;

import dao.CourseDAO;
import dao.UserDAO;
import dao.DatabaseException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Course;
import model.Professor;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class CourseManagementController implements Initializable {

    @FXML
    private TextField courseCodeField;

    @FXML
    private TextField courseNameField;

    @FXML
    private TextField creditsField;

    @FXML
    private ComboBox<Professor> professorComboBox;

    @FXML
    private CheckBox availableCheckBox;

    @FXML
    private TableView<Course> coursesTable;

    @FXML
    private TableColumn<Course, Integer> courseIdColumn;

    @FXML
    private TableColumn<Course, String> courseCodeColumn;

    @FXML
    private TableColumn<Course, String> courseNameColumn;

    @FXML
    private TableColumn<Course, Integer> creditsColumn;

    @FXML
    private TableColumn<Course, String> professorColumn;

    @FXML
    private TableColumn<Course, String> availabilityColumn;

    private CourseDAO courseDAO = new CourseDAO();
    private UserDAO userDAO = new UserDAO();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        courseIdColumn.setCellValueFactory(new PropertyValueFactory<>("courseId"));
        courseCodeColumn.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        courseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        creditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        professorColumn.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(cellData.getValue().getProfessorName()));
        availabilityColumn.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().isAvailable() ? "Available" : "Unavailable"));

        coursesTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                populateFields(newSelection);
            }
        });

        loadProfessors();
        loadCourses();
    }

    private void loadProfessors() {
        try {
            ArrayList<Professor> professors = userDAO.getAllProfessors();
            ObservableList<Professor> professorList = FXCollections.observableArrayList(professors);
            professorComboBox.setItems(professorList);
        } catch (DatabaseException e) {
            showError("Failed to load professors: " + e.getMessage());
        }
    }

    private void loadCourses() {
        try {
            ArrayList<Course> courses = courseDAO.getAllCourses();
            ObservableList<Course> courseList = FXCollections.observableArrayList(courses);
            coursesTable.setItems(courseList);
        } catch (DatabaseException e) {
            showError("Failed to load courses: " + e.getMessage());
        }
    }

    private void populateFields(Course course) {
        courseCodeField.setText(course.getCourseCode());
        courseNameField.setText(course.getCourseName());
        creditsField.setText(String.valueOf(course.getCredits()));
        availableCheckBox.setSelected(course.isAvailable());

        if (course.getProfessor() != null) {
            for (Professor prof : professorComboBox.getItems()) {
                if (prof.getUserId() == course.getProfessor().getUserId()) {
                    professorComboBox.setValue(prof);
                    break;
                }
            }
        }
    }

    @FXML
    private void handleAdd() {
        if (!validateInput()) {
            return;
        }

        try {
            Course course = createCourseFromFields();
            courseDAO.add(course);
            showSuccess("Course added successfully");
            loadCourses();
            handleClear();
        } catch (DatabaseException e) {
            showError("Failed to add course: " + e.getMessage());
        }
    }

    @FXML
    private void handleUpdate() {
        Course selectedCourse = coursesTable.getSelectionModel().getSelectedItem();
        if (selectedCourse == null) {
            showWarning("Please select a course to update");
            return;
        }

        if (!validateInput()) {
            return;
        }

        try {
            Course course = createCourseFromFields();
            course.setCourseId(selectedCourse.getCourseId());
            courseDAO.update(course);
            showSuccess("Course updated successfully");
            loadCourses();
            handleClear();
        } catch (DatabaseException e) {
            showError("Failed to update course: " + e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        Course selectedCourse = coursesTable.getSelectionModel().getSelectedItem();
        if (selectedCourse == null) {
            showWarning("Please select a course to delete");
            return;
        }

        try {
            courseDAO.delete(selectedCourse.getCourseId());
            showSuccess("Course deleted successfully");
            loadCourses();
            handleClear();
        } catch (DatabaseException e) {
            showError("Failed to delete course: " + e.getMessage());
        }
    }

    @FXML
    private void handleClear() {
        courseCodeField.clear();
        courseNameField.clear();
        creditsField.clear();
        professorComboBox.setValue(null);
        availableCheckBox.setSelected(false);
        coursesTable.getSelectionModel().clearSelection();
    }

    @FXML
    private void handleBack() {
        loadScene("/fxml/AdminDashboard.fxml", "Admin Dashboard");
    }

    private boolean validateInput() {
        if (courseCodeField.getText().trim().isEmpty() ||
            courseNameField.getText().trim().isEmpty() ||
            creditsField.getText().trim().isEmpty()) {
            showWarning("Please fill in all required fields");
            return false;
        }

        try {
            Integer.parseInt(creditsField.getText().trim());
        } catch (NumberFormatException e) {
            showWarning("Credits must be a valid number");
            return false;
        }

        return true;
    }

    private Course createCourseFromFields() {
        Course course = new Course();
        course.setCourseCode(courseCodeField.getText().trim());
        course.setCourseName(courseNameField.getText().trim());
        course.setCredits(Integer.parseInt(creditsField.getText().trim()));
        course.setProfessor(professorComboBox.getValue());
        course.setAvailable(availableCheckBox.isSelected());
        return course;
    }

    private void loadScene(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) coursesTable.getScene().getWindow();
            stage.setScene(new Scene(root, 800, 600));
            stage.setTitle(title);
        } catch (IOException e) {
            System.err.println("Failed to load scene: " + e.getMessage());
        }
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
