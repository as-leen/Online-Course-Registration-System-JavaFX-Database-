package controller;

import dao.UserDAO;
import dao.DatabaseException;
import model.AuthenticationException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private ComboBox<String> roleComboBox;

    @FXML
    private Label errorLabel;

    private UserDAO userDAO = new UserDAO();
    private static User currentUser;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        roleComboBox.getItems().addAll("STUDENT", "PROFESSOR", "ADMIN");
        roleComboBox.setValue("STUDENT");
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();
        String role = roleComboBox.getValue();

        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Please enter username and password");
            return;
        }

        try {
            User user = userDAO.login(username, password, role);
            currentUser = user;

            String fxmlFile = "";
            switch (role) {
                case "STUDENT":
                    fxmlFile = "/fxml/StudentDashboard.fxml";
                    break;
                case "PROFESSOR":
                    fxmlFile = "/fxml/ProfessorDashboard.fxml";
                    break;
                case "ADMIN":
                    fxmlFile = "/fxml/AdminDashboard.fxml";
                    break;
            }

            loadScene(fxmlFile, user.getRole() + " Dashboard");

        } catch (AuthenticationException e) {
            errorLabel.setText(e.getMessage());
        } catch (DatabaseException e) {
            errorLabel.setText("Database error: " + e.getMessage());
        }
    }

    private void loadScene(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(new Scene(root, 800, 600));
            stage.setTitle(title);
        } catch (IOException e) {
            errorLabel.setText("Failed to load dashboard: " + e.getMessage());
        }
    }

    public static User getCurrentUser() {
        return currentUser;
    }
}
