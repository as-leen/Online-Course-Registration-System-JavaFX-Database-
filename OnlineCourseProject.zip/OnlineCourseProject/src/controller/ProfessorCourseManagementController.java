package controller;

import dao.CourseDAO;
import dao.EnrollmentDAO;
import dao.DatabaseException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Course;
import model.Student;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Consolidated controller for professor course management
 * Handles viewing courses, enrolled students, and updating course availability
 */
public class ProfessorCourseManagementController implements Initializable {

    @FXML
    private TabPane professorTabPane;

    // My Courses Tab Components
    @FXML
    private TableView<Course> myCoursesTable;

    @FXML
    private TableColumn<Course, String> myCourseCodeColumn;

    @FXML
    private TableColumn<Course, String> myCourseNameColumn;

    @FXML
    private TableColumn<Course, Integer> myCreditsColumn;

    @FXML
    private TableColumn<Course, String> myAvailabilityColumn;

    // Enrolled Students Tab Components
    @FXML
    private ComboBox<Course> courseComboBox;

    @FXML
    private TableView<Student> studentsTable;

    @FXML
    private TableColumn<Student, Integer> studentIdColumn;

    @FXML
    private TableColumn<Student, String> firstNameColumn;

    @FXML
    private TableColumn<Student, String> lastNameColumn;

    @FXML
    private TableColumn<Student, String> usernameColumn;

    // Update Availability Tab Components
    @FXML
    private TableView<Course> availabilityTable;

    @FXML
    private TableColumn<Course, String> availCourseCodeColumn;

    @FXML
    private TableColumn<Course, String> availCourseNameColumn;

    @FXML
    private TableColumn<Course, Integer> availCreditsColumn;

    @FXML
    private TableColumn<Course, String> availStatusColumn;

    @FXML
    private Button makeAvailableButton;

    @FXML
    private Button makeUnavailableButton;

    private CourseDAO courseDAO = new CourseDAO();
    private EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private User currentUser;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        currentUser = LoginController.getCurrentUser();

        // Initialize My Courses Tab
        myCourseCodeColumn.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        myCourseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        myCreditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        myAvailabilityColumn.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().isAvailable() ? "Available" : "Unavailable"));

        // Initialize Enrolled Students Tab
        studentIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));

        // Initialize Update Availability Tab
        availCourseCodeColumn.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        availCourseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        availCreditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        availStatusColumn.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(
                cellData.getValue().isAvailable() ? "Available" : "Unavailable"));

        // Load data
        loadProfessorCourses();
        loadCourseComboBox();

        // Add tab change listener to refresh data
        professorTabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab != null) {
                loadProfessorCourses();
                loadCourseComboBox();
            }
        });
    }

    private void loadProfessorCourses() {
        try {
            ArrayList<Course> courses = courseDAO.getCoursesByProfessor(currentUser.getUserId());
            ObservableList<Course> courseList = FXCollections.observableArrayList(courses);
            myCoursesTable.setItems(courseList);
            availabilityTable.setItems(courseList);
        } catch (DatabaseException e) {
            showError("Failed to load courses: " + e.getMessage());
        }
    }

    private void loadCourseComboBox() {
        try {
            ArrayList<Course> courses = courseDAO.getCoursesByProfessor(currentUser.getUserId());
            ObservableList<Course> courseList = FXCollections.observableArrayList(courses);
            courseComboBox.setItems(courseList);
        } catch (DatabaseException e) {
            showError("Failed to load courses: " + e.getMessage());
        }
    }

    @FXML
    private void handleCourseSelection() {
        Course selectedCourse = courseComboBox.getSelectionModel().getSelectedItem();
        if (selectedCourse != null) {
            loadEnrolledStudents(selectedCourse.getCourseId());
        }
    }

    private void loadEnrolledStudents(int courseId) {
        try {
            ArrayList<Student> students = enrollmentDAO.getEnrollmentsByCourse(courseId);
            ObservableList<Student> studentList = FXCollections.observableArrayList(students);
            studentsTable.setItems(studentList);
        } catch (DatabaseException e) {
            showError("Failed to load enrolled students: " + e.getMessage());
        }
    }

    @FXML
    private void handleMakeAvailable() {
        Course selectedCourse = availabilityTable.getSelectionModel().getSelectedItem();

        if (selectedCourse == null) {
            showWarning("Please select a course");
            return;
        }

        try {
            courseDAO.updateAvailability(selectedCourse.getCourseId(), true);
            showSuccess("Course " + selectedCourse.getCourseCode() + " is now available");
            loadProfessorCourses();
        } catch (DatabaseException e) {
            showError("Failed to update availability: " + e.getMessage());
        }
    }

    @FXML
    private void handleMakeUnavailable() {
        Course selectedCourse = availabilityTable.getSelectionModel().getSelectedItem();

        if (selectedCourse == null) {
            showWarning("Please select a course");
            return;
        }

        try {
            courseDAO.updateAvailability(selectedCourse.getCourseId(), false);
            showSuccess("Course " + selectedCourse.getCourseCode() + " is now unavailable");
            loadProfessorCourses();
        } catch (DatabaseException e) {
            showError("Failed to update availability: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack() {
        loadScene("/fxml/ProfessorDashboard.fxml", "Professor Dashboard");
    }

    private void loadScene(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) professorTabPane.getScene().getWindow();
            stage.setScene(new Scene(root, 800, 600));
            stage.setTitle(title);
        } catch (IOException e) {
            System.err.println("Failed to load scene: " + e.getMessage());
        }
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
