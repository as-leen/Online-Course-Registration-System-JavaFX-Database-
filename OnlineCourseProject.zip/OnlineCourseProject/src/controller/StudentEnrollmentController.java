package controller;

import dao.CourseDAO;
import dao.EnrollmentDAO;
import dao.DatabaseException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Course;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Consolidated controller for student enrollment operations
 * Handles both course registration and dropping courses
 */
public class StudentEnrollmentController implements Initializable {

    @FXML
    private TabPane enrollmentTabPane;

    // Registration Tab Components
    @FXML
    private TableView<Course> availableCoursesTable;

    @FXML
    private TableColumn<Course, String> regCourseCodeColumn;

    @FXML
    private TableColumn<Course, String> regCourseNameColumn;

    @FXML
    private TableColumn<Course, Integer> regCreditsColumn;

    @FXML
    private TableColumn<Course, String> regProfessorColumn;

    @FXML
    private Button registerButton;

    // Drop Course Tab Components
    @FXML
    private TableView<Course> enrolledCoursesTable;

    @FXML
    private TableColumn<Course, String> dropCourseCodeColumn;

    @FXML
    private TableColumn<Course, String> dropCourseNameColumn;

    @FXML
    private TableColumn<Course, Integer> dropCreditsColumn;

    @FXML
    private TableColumn<Course, String> dropProfessorColumn;

    @FXML
    private Button dropButton;

    private CourseDAO courseDAO = new CourseDAO();
    private EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private User currentUser;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        currentUser = LoginController.getCurrentUser();

        // Initialize Registration Tab
        regCourseCodeColumn.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        regCourseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        regCreditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        regProfessorColumn.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(cellData.getValue().getProfessorName()));

        // Initialize Drop Tab
        dropCourseCodeColumn.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        dropCourseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        dropCreditsColumn.setCellValueFactory(new PropertyValueFactory<>("credits"));
        dropProfessorColumn.setCellValueFactory(cellData ->
            new javafx.beans.property.SimpleStringProperty(cellData.getValue().getProfessorName()));

        // Load data
        loadAvailableCourses();
        loadEnrolledCourses();

        // Add tab change listener to refresh data
        enrollmentTabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab != null) {
                loadAvailableCourses();
                loadEnrolledCourses();
            }
        });
    }

    private void loadAvailableCourses() {
        try {
            ArrayList<Course> courses = courseDAO.getAvailableCourses();
            ObservableList<Course> courseList = FXCollections.observableArrayList(courses);
            availableCoursesTable.setItems(courseList);
        } catch (DatabaseException e) {
            showError("Failed to load available courses: " + e.getMessage());
        }
    }

    private void loadEnrolledCourses() {
        try {
            ArrayList<Course> courses = enrollmentDAO.getEnrollmentsByStudent(currentUser.getUserId());
            ObservableList<Course> courseList = FXCollections.observableArrayList(courses);
            enrolledCoursesTable.setItems(courseList);
        } catch (DatabaseException e) {
            showError("Failed to load enrolled courses: " + e.getMessage());
        }
    }

    @FXML
    private void handleRegister() {
        Course selectedCourse = availableCoursesTable.getSelectionModel().getSelectedItem();

        if (selectedCourse == null) {
            showWarning("Please select a course to register");
            return;
        }

        try {
            enrollmentDAO.enrollStudent(currentUser.getUserId(), selectedCourse.getCourseId());
            showSuccess("Successfully registered for " + selectedCourse.getCourseCode());
            loadAvailableCourses();
            loadEnrolledCourses();
        } catch (DatabaseException e) {
            showError("Registration failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleDrop() {
        Course selectedCourse = enrolledCoursesTable.getSelectionModel().getSelectedItem();

        if (selectedCourse == null) {
            showWarning("Please select a course to drop");
            return;
        }

        try {
            enrollmentDAO.dropCourse(currentUser.getUserId(), selectedCourse.getCourseId());
            showSuccess("Successfully dropped " + selectedCourse.getCourseCode());
            loadAvailableCourses();
            loadEnrolledCourses();
        } catch (DatabaseException e) {
            showError("Failed to drop course: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack() {
        loadScene("/fxml/StudentDashboard.fxml", "Student Dashboard");
    }

    private void loadScene(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = (Stage) enrollmentTabPane.getScene().getWindow();
            stage.setScene(new Scene(root, 800, 600));
            stage.setTitle(title);
        } catch (IOException e) {
            System.err.println("Failed to load scene: " + e.getMessage());
        }
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showWarning(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
