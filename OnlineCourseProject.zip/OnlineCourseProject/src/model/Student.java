package model;

public class Student extends User {

    public Student() {
        super();
    }

    public Student(int userId, String username, String password, String firstName, String lastName) {
        super(userId, username, password, firstName, lastName, "STUDENT");
    }

    @Override
    public String toString() {
        return "Student{" +
                "userId=" + getUserId() +
                ", username='" + getUsername() + '\'' +
                ", firstName='" + getFirstName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                '}';
    }
}
