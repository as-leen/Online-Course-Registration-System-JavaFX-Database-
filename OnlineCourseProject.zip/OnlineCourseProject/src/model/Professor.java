package model;

public class Professor extends User {

    public Professor() {
        super();
    }

    public Professor(int userId, String username, String password, String firstName, String lastName) {
        super(userId, username, password, firstName, lastName, "PROFESSOR");
    }

    @Override
    public String toString() {
        return getFullName();
    }
}
