package model;

public class Administrator extends User {

    public Administrator() {
        super();
    }

    public Administrator(int userId, String username, String password, String firstName, String lastName) {
        super(userId, username, password, firstName, lastName, "ADMIN");
    }

    @Override
    public String toString() {
        return "Administrator{" +
                "userId=" + getUserId() +
                ", username='" + getUsername() + '\'' +
                ", firstName='" + getFirstName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                '}';
    }
}
